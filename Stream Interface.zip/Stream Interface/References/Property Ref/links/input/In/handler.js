function handler(In) {
    var self = this;
    this.property = In;
    self.executeOutputLink("Out", In);
}