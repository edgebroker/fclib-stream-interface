function handler(In) {
    var self = this;
    this.memory = In;
    self.executeOutputLink("Out", In);
}