function handler(In) {
    this.executeOutputLink("Out", stream.create().message().message());
}