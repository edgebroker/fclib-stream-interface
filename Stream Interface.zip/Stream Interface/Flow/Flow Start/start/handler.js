function handler() {
    this.executeOutputLink("Out", stream.create().message().message());
}