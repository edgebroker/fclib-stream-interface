function handler(In) {
    this.executeOutputLink(In.type(), In);
}