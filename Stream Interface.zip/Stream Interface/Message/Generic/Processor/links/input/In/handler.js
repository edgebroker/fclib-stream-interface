function handler(In) {
    this.executeOutputLink("Out", operation(In));

    function operation(In) {
        /*${operation}*/
    }
}