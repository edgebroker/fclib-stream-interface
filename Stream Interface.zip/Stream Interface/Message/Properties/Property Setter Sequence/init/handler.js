function handler() {
    this.INTEGER = Java.type("java.lang.Integer");
    this.sequencevalue = this.INTEGER.parseInt(this.props["initvalue"]);
}