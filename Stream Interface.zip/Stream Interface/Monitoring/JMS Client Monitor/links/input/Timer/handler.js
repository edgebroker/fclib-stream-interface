function handler(Timer) {
    this.checkState();
}