function handler(timer) {
    stream.memory(this.compid).checkLimit();
}