function handler() {
    stream.create().output(this.props["topicname"]).topic();
}