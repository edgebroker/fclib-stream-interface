function handler(In) {
    this.executor();
    this.executeOutputLink("Out", In);
}