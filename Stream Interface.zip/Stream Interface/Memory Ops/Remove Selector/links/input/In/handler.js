function handler(In) {
    this.executeOutputLink("Result", mem.remove(this.props["selector"]));
}