function handler(In) {
    var self = this;
    self.executeOutputLink("Out", In.max(this.props["property"]));
}